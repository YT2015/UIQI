clear
clc

I = imread('1.png');
score = uiqi_index(I)