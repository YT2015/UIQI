SVM version: libsvm-3.20 libsvm-3.22

please cite the following paper:

Y. Liu et al., "UIQI: A Comprehensive Quality Evaluation Index for Underwater Images," in IEEE Transactions on Multimedia, doi: 10.1109/TMM.2023.3301226.

please run demo.m for usage