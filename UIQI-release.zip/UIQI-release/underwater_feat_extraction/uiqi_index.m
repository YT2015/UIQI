
function score = uiqi_index(img)

load uiqi_model;

label = 0;

ff = uiqi_feat_extract(img);

[score, accuracy, dec_values]  = svmpredict(label, ff, svmmodel);


end