function xx = lyt_normalize(x)

maxx = max(x);
minn = min(x);

xx = (x - minn)/(maxx-minn);

end